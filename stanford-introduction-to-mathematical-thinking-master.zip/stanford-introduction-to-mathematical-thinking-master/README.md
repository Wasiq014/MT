# Stanford: Introduction to Mathematical Thinking
Keith Devlin's Introduction to Mathematical Thinking course on Coursera (2017 Spring)
